<?php
	$mysql_server = "localhost";
//echo $_SERVER['HTTP_HOST'];
	if ( $_SERVER['HTTP_HOST'] == "localhost" ) {
   	 $mysql_username = "root";
   	$mysql_password = "(*Allaahisone99*)";
   } else {
   	$mysql_username = "root";
   	$mysql_password = "(*Allaahisone99*)";
   }

   $center_db = "bais_center";
   
 
?>