<title>Islamic Online University - BAIS</title>
<link rel="shortcut icon" href="http://bais.islamiconlineuniversity.com/bais/theme/ingenuous/favicon.ico" />
<table width= "100%">
<tr  width= "100%" bgcolor="#000000" class="td_data">
	<td width= "15%"><span><strong><a href="allcenters.php">All Centers </a></strong></span></td>
    <td width= "15%"><span><strong><a href="stdreqview.php">Center Requests </a></strong></span></td>
  <td width= "15%"><span><strong><a href="adminaddcenter.php">Add New Center </a></strong></span></td>
   <td width= "15%"><span><strong><a href="adminaddproctor.php">Add Proctor </a></strong></span></td>
   <td width= "15%"><span><strong><a href="noticeboard.php">Post News </a></strong></span></td> 
   <td width= "15%"><span><strong><a href="centerupdate.php">Update Center </a></strong></span></td> 
       
</tr>
</table>