<title>Islamic Online University Exam Centers Registration--Admin Panel</title>
<link rel="shortcut icon" href="http://bais.islamiconlineuniversity.com/bais/theme/ingenuous/favicon.ico" />
<link rel="stylesheet" type="text/css" href="menustyle.css" media="screen, print" />  


    <script src="menuscript.js" language="javascript" type="text/javascript"></script>
<center>
<table border="0" cellpadding="0" cellspacing="0" width="100%"><tr bgcolor="#FFF"><td>
<a href="allcenters.php" onmouseover="setOverImg('1','');" onmouseout="setOutImg('1','');" target=""><img width="16%" src="buttons/button1up.png" border="0" id="button1" vspace="1" hspace="1"></a>
<a href="stdreqview.php" onmouseover="setOverImg('2','');" onmouseout="setOutImg('2','');" target=""><img width="16%" src="buttons/button2up.png" border="0" id="button2" vspace="1" hspace="1"></a>
<a href="adminaddcenter.php" onmouseover="setOverImg('3','');" onmouseout="setOutImg('3','');" target=""><img width="16%" src="buttons/button3up.png" border="0" id="button3" vspace="1" hspace="1"></a>
<a href="adminaddproctor.php" onmouseover="setOverImg('4','');" onmouseout="setOutImg('4','');" target=""><img width="16%" src="buttons/button4up.png" border="0" id="button4" vspace="1" hspace="1"></a>
<a href="noticeboard.php" onmouseover="setOverImg('5','');" onmouseout="setOutImg('5','');" target=""><img width="16%" src="buttons/button5up.png" border="0" id="button5" vspace="1" hspace="1"></a>
<a href="centerupdate.php" onmouseover="setOverImg('6','');" onmouseout="setOutImg('6','');" target=""><img width="16%" src="buttons/button6up.png" border="0" id="button6" vspace="1" hspace="1"></a>
</td></tr></table>

</center>
